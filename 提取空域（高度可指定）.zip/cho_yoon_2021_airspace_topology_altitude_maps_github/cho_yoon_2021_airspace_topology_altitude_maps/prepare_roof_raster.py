"""Build the buffered maximum-roof raster from prepared building polygons."""

from pathlib import Path

import numpy as np
import pyogrio
import rasterio
from rasterio.features import rasterize

import altitude_config as settings


def prepare_roof(data_dir):
    data_dir = Path(data_dir)
    dem_path = data_dir / "hangzhou_dem_utm51_30m.tif"
    buildings_path = data_dir / "hangzhou_buildings_prepared.gpkg"
    output = data_dir / "roof_clearance_max_30m.tif"
    with rasterio.open(dem_path) as source:
        profile = source.profile
        if not np.allclose(source.res, (30, 30)) or source.crs is None or not source.crs.is_projected:
            raise ValueError("Prepared DEM must use a projected 30 m grid")
    buildings = pyogrio.read_dataframe(buildings_path, layer="buildings", columns=["top_altitude_m"])
    if buildings.crs is None or buildings.empty:
        raise ValueError("Prepared buildings must be nonempty and declare their CRS")
    if buildings.crs != profile["crs"]:
        buildings = buildings.to_crs(profile["crs"])
    heights = np.asarray(buildings.top_altitude_m, dtype=float)
    if not np.isfinite(heights).all() or buildings.geometry.is_empty.any() or buildings.geometry.isna().any():
        raise ValueError("Prepared buildings contain missing roof elevations or empty geometry")
    # Highest roof wins when buffered building polygons overlap.
    shapes = ((buildings.geometry.iloc[int(i)].buffer(30.0), float(heights[int(i)]))
              for i in np.argsort(heights))
    values = rasterize(shapes, out_shape=(profile["height"], profile["width"]),
                       transform=profile["transform"], fill=-9999.0,
                       dtype="float32", all_touched=False)
    profile.pop("predictor", None)
    profile.update(driver="GTiff", count=1, dtype="float32", nodata=-9999,
                   compress="DEFLATE", tiled=True, blockxsize=256, blockysize=256)
    with rasterio.open(output, "w", **profile) as target:
        target.write(values, 1)
        target.update_tags(building_clearance_m=30, top_field="top_altitude_m",
                           rasterization="pixel centre; maximum roof wins overlaps")
    return output


if __name__ == "__main__":
    print(prepare_roof(settings.DATA_DIR))
