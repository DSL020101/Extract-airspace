@echo off
setlocal
set "PYTHONUTF8=1"
chcp 65001 >nul
pushd "%~dp0"
set "RUN_PYTHON="
if defined AIRSPACE_PYTHON set "RUN_PYTHON=%AIRSPACE_PYTHON%"
if not defined RUN_PYTHON if exist "%~dp0.venv\Scripts\python.exe" set "RUN_PYTHON=%~dp0.venv\Scripts\python.exe"
if not defined RUN_PYTHON if exist "%~dp0python_path.local" set /p "RUN_PYTHON="<"%~dp0python_path.local"
if not defined RUN_PYTHON set "RUN_PYTHON=python"
"%RUN_PYTHON%" -B "%~dp0draw_altitude.py" %*
set "RUN_EXIT=%ERRORLEVEL%"
if not "%RUN_EXIT%"=="0" echo Map generation failed. Read the error above.
popd
pause
exit /b %RUN_EXIT%
