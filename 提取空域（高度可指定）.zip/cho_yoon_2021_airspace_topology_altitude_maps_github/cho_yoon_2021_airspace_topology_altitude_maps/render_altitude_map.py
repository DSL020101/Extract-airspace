"""Render scientific map arrays; usable in the existing matplotlib environment."""

import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("array")
    parser.add_argument("output")
    parser.add_argument("--altitude", required=True)
    parser.add_argument("--dpi", type=int, default=260)
    parser.add_argument("--legend", action="store_true")
    args = parser.parse_args()
    with np.load(args.array) as source:
        values = source["values"]
    classes = np.where(values == 255, 2, values)
    fig, ax = plt.subplots(figsize=(13, 8.5), layout="constrained")
    colors = ["#d8dde4", "#078f99", "#ffffff"]
    ax.imshow(classes, cmap=ListedColormap(colors), vmin=0, vmax=2,
              interpolation="nearest")
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_linewidth(0.8)
    ax.text(0.02, 0.96, "N ↑", transform=ax.transAxes,
            ha="left", va="top", fontsize=12)
    ax.set_title(f"Hangzhou candidate free space | Absolute altitude {args.altitude} m",
                 fontsize=18, pad=10)
    if args.legend:
        ax.legend(handles=[Patch(facecolor=c, label=t) for c, t in zip(
            colors, ["Candidate free", "Blocked", "Outside Hangzhou"])], loc="lower left")
    fig.savefig(args.output, dpi=args.dpi, facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
