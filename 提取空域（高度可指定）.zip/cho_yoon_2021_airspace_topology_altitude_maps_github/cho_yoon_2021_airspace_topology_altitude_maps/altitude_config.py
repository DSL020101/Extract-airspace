"""Change ALTITUDE_M, save this file, then run run_altitude_map.cmd."""

from pathlib import Path

# Target absolute altitude in metres. Integer values give 1 m increments.
ALTITUDE_M = 71

PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR / "data"
OUTPUT_DIR = PROJECT_DIR / "outputs"

# Plot style: matches the existing citywide maps, without the lower-left legend.
SHOW_LEGEND = False
FIGURE_DPI = 260
PREVIEW_MAX_WIDTH = 2600

# Normally matplotlib runs in the same Python environment.
# Optional fallback: set another interpreter here or in plot_python_path.local.
PLOT_PYTHON = None
