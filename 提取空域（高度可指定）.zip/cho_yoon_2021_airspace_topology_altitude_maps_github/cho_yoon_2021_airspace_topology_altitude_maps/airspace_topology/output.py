"""GeoPackage and graph/metric exports for each altitude."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import geopandas as gpd
from shapely.ops import unary_union


def _write_gpkg(path, layer_name, records, crs):
    records = [r for r in records if r["geometry"] is not None
               and not r["geometry"].is_empty]
    if not records:
        return
    frame = gpd.GeoDataFrame(records, geometry="geometry", crs=crs)
    frame.to_file(path, layer=layer_name, driver="GPKG", engine="pyogrio")


def write_layer(out_dir, layer, crs, study_area, free_space):
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    name = f"layer_{layer.altitude:g}m.gpkg"
    path = output / name
    if path.exists():
        path.unlink()
    _write_gpkg(path, "study_area", [{"geometry": study_area}], crs)
    _write_gpkg(path, "free_after_clearance", [{"geometry": free_space}], crs)
    _write_gpkg(path, "segments", [
        {"id": s.id, "altitude_m": layer.altitude, "area_m2": s.area,
         "volume_m3": s.area * layer.thickness,
         "degree": s.degree, "geometry": s.geometry}
        for s in layer.segments], crs)
    _write_gpkg(path, "passages", [
        {"id": p.id, "altitude_m": layer.altitude, "area_m2": p.area,
         "volume_m3": p.area * layer.thickness,
         "type": p.passage_type, "max_circle_radius_m": p.maximum_inscribed_radius,
         "vehicle_capacity": p.vehicle_capacity, "geometry": p.geometry}
        for p in layer.passages], crs)
    _write_gpkg(path, "gates", [
        {"id": g.id, "segment_id": g.segment_id, "passage_id": g.passage_id,
         "segment_triangle": g.segment_triangle_id,
         "passage_triangle": g.passage_triangle_id, "geometry": g.shared_edge}
        for g in layer.gates], crs)
    _write_gpkg(path, "gate_triangles", [
        {"gate_id": g.id, "segment_id": g.segment_id,
         "passage_id": g.passage_id,
         "triangle_id": g.segment_triangle_id,
         "geometry": layer.mesh.polygons[g.segment_triangle_id]}
        for g in layer.gates], crs)
    closed = [layer.mesh.polygons[i] for i, rho in enumerate(layer.mesh.radii)
              if rho < layer.containment_radius]
    if closed:
        _write_gpkg(path, "closed_by_r", [{"geometry": unary_union(closed)}], crs)
    graph = {
        "altitude_m": layer.altitude,
        "layer_thickness_m": layer.thickness,
        "nodes": ([{"id": s.id, "kind": "segment", "area_m2": s.area,
                    "volume_m3": s.area * layer.thickness,
                    "degree": s.degree} for s in layer.segments]
                  + [{"id": p.id, "kind": "passage", "type": p.passage_type,
                      "area_m2": p.area,
                      "volume_m3": p.area * layer.thickness,
                      "maximum_inscribed_radius_m": p.maximum_inscribed_radius,
                      "vehicle_capacity": p.vehicle_capacity} for p in layer.passages]),
        "edges": [{"segment": s, "passage": p} for s, p in layer.segment_passage_edges],
        "gates": [{"id": g.id, "segment": g.segment_id, "passage": g.passage_id,
                   "segment_triangle": g.segment_triangle_id,
                   "passage_triangle": g.passage_triangle_id} for g in layer.gates],
    }
    (output / f"segment_graph_{layer.altitude:g}m.json").write_text(
        json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def write_summary(out_dir, layers, vertical, metadata):
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    with (output / "metrics.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        if layers:
            writer = csv.DictWriter(stream, fieldnames=list(layers[0].metrics))
            writer.writeheader()
            writer.writerows(layer.metrics for layer in layers)
    nodes = [
        {"id": f"h{layer.altitude:g}_{segment.id}",
         "altitude_m": layer.altitude, "segment_id": segment.id,
         "area_m2": segment.area, "volume_m3": segment.area * layer.thickness,
         "degree": segment.degree}
        for layer in layers for segment in layer.segments
    ]
    (output / "vertical_graph.json").write_text(
        json.dumps({"nodes": nodes, "edges": vertical}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    (output / "run_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
