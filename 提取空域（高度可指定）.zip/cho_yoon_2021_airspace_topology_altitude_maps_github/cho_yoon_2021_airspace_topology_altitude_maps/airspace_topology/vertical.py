"""Section 4.3: sampled-height Reeb-style graph by polygon intersection."""

from __future__ import annotations

from shapely.strtree import STRtree

from .filtration import LayerResult


def vertical_edges(layers: list[LayerResult], minimum_overlap_area: float = 0.0):
    """Connect segment polygons in consecutive altitude planes.

    A zero threshold uses the paper's unqualified 'polygon intersection',
    including an edge/point touch. Set a positive area to suppress such
    contacts when a physically traversable vertical corridor is required.
    """
    if minimum_overlap_area < 0:
        raise ValueError("minimum_overlap_area must be nonnegative")
    ordered = sorted(layers, key=lambda x: x.altitude)
    edges = []
    for lower, upper in zip(ordered, ordered[1:]):
        if abs((upper.altitude - lower.altitude) - lower.thickness) > 1e-8:
            continue
        geoms = [segment.geometry for segment in upper.segments]
        if not geoms:
            continue
        tree = STRtree(geoms)
        for lower_segment in lower.segments:
            for upper_index in tree.query(lower_segment.geometry, predicate="intersects"):
                upper_segment = upper.segments[int(upper_index)]
                intersection = lower_segment.geometry.intersection(upper_segment.geometry)
                overlap_area = float(intersection.area)
                if not intersection.is_empty and overlap_area >= minimum_overlap_area:
                    edges.append({
                        "from": f"h{lower.altitude:g}_{lower_segment.id}",
                        "to": f"h{upper.altitude:g}_{upper_segment.id}",
                        "from_altitude_m": lower.altitude,
                        "to_altitude_m": upper.altitude,
                        "overlap_area_m2": overlap_area,
                    })
    return edges
