"""Adapters for vector buildings and digital elevation models (DEM)."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil, isfinite
from pathlib import Path

import numpy as np
import pyogrio
import rasterio
from pyproj import CRS, Transformer
from rasterio.enums import Resampling
from rasterio.features import geometry_mask, shapes
from rasterio.transform import from_origin, rowcol
from rasterio.vrt import WarpedVRT
from rasterio.windows import Window, transform as window_transform
from shapely.geometry import Point, shape
from shapely.ops import unary_union


VECTOR_SUFFIXES = {".shp", ".gpkg", ".geojson", ".fgb"}
RASTER_SUFFIXES = {".tif", ".tiff", ".vrt"}


def collect_paths(entries, suffixes):
    paths = []
    for entry in entries:
        path = Path(entry)
        if not path.exists():
            raise FileNotFoundError(path)
        if path.is_dir():
            paths.extend(p for p in path.rglob("*") if p.suffix.lower() in suffixes)
        elif path.suffix.lower() in suffixes:
            paths.append(path)
        else:
            raise ValueError(f"Unsupported format: {path}")
    unique = sorted(set(paths))
    if not unique:
        raise ValueError(f"No supported files found in {entries}")
    return unique


def utm_crs(longitude, latitude):
    zone = min(60, max(1, int((longitude + 180) // 6) + 1))
    return CRS.from_epsg((32600 if latitude >= 0 else 32700) + zone)


def make_study_area(center_lon=None, center_lat=None, radius_m=None,
                    boundary_path=None, metric_crs=None):
    if boundary_path:
        frame = pyogrio.read_dataframe(boundary_path)
        if frame.crs is None or frame.empty:
            raise ValueError("Boundary needs geometry and a declared CRS")
        point = frame.to_crs("EPSG:4326").geometry.union_all().representative_point()
        crs = CRS.from_user_input(metric_crs) if metric_crs else utm_crs(point.x, point.y)
        area = frame.to_crs(crs).geometry.union_all()
        return (area if area.is_valid else area.buffer(0)), crs
    if center_lon is None or center_lat is None or radius_m is None:
        raise ValueError("Provide --boundary or center longitude/latitude and radius")
    if radius_m <= 0:
        raise ValueError("radius_m must be positive")
    crs = CRS.from_user_input(metric_crs) if metric_crs else utm_crs(center_lon, center_lat)
    x, y = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform(center_lon, center_lat)
    return Point(x, y).buffer(radius_m, quad_segs=64), crs


@dataclass
class DEMGrid:
    values: np.ndarray
    transform: object
    crs: CRS

    def sample(self, x, y):
        row, col = rowcol(self.transform, x, y)
        if not (0 <= row < self.values.shape[0] and 0 <= col < self.values.shape[1]):
            return float("nan")
        return float(self.values[row, col])

    def sample_building_ground(self, footprint):
        """Use the median DEM elevation when a building touches multiple cells."""
        minx, miny, maxx, maxy = footprint.bounds
        first_row, first_col = rowcol(self.transform, minx, maxy)
        last_row, last_col = rowcol(self.transform, maxx, miny)
        first_row, first_col = max(0, first_row), max(0, first_col)
        last_row = min(self.values.shape[0] - 1, last_row)
        last_col = min(self.values.shape[1] - 1, last_col)
        if first_row > last_row or first_col > last_col:
            return float("nan"), 0
        window = Window(first_col, first_row,
                        last_col - first_col + 1, last_row - first_row + 1)
        cells = self.values[first_row:last_row + 1, first_col:last_col + 1]
        covered = geometry_mask([footprint], out_shape=cells.shape,
                                transform=window_transform(window, self.transform),
                                invert=True, all_touched=True)
        elevations = cells[covered & np.isfinite(cells)]
        if not elevations.size:
            return float("nan"), 0
        if elevations.size == 1:
            return float(elevations[0]), 1
        return float(np.median(elevations)), int(elevations.size)

    def terrain_obstacles(self, altitude, clip_area):
        mask = np.isfinite(self.values) & (self.values >= altitude)
        if not mask.any():
            return []
        polygons = [shape(geom) for geom, value in shapes(
            mask.astype(np.uint8), mask=mask, transform=self.transform) if value == 1]
        clipped = unary_union(polygons).intersection(clip_area)
        if clipped.is_empty:
            return []
        if clipped.geom_type == "Polygon":
            return [clipped]
        return [g for g in getattr(clipped, "geoms", []) if g.geom_type == "Polygon"]


def load_dem(paths, study_area, metric_crs, pixel_size_m, clearance_m):
    if pixel_size_m <= 0:
        raise ValueError("pixel_size_m must be positive")
    expanded = study_area.buffer(clearance_m + pixel_size_m)
    minx, miny, maxx, maxy = expanded.bounds
    width = ceil((maxx - minx) / pixel_size_m)
    height = ceil((maxy - miny) / pixel_size_m)
    if width * height > 100_000_000:
        raise MemoryError("DEM grid exceeds 100 million cells; use a smaller area or coarser pixels")
    transform = from_origin(minx, maxy, pixel_size_m, pixel_size_m)
    mosaic = np.full((height, width), np.nan, dtype=np.float32)
    for path in paths:
        with rasterio.open(path) as source:
            if source.crs is None:
                raise ValueError(f"DEM lacks CRS: {path}")
            with WarpedVRT(source, crs=metric_crs, transform=transform,
                           width=width, height=height,
                           resampling=Resampling.bilinear,
                           nodata=np.nan) as vrt:
                tile = vrt.read(1, masked=True).filled(np.nan)
                fill = np.isnan(mosaic) & np.isfinite(tile)
                mosaic[fill] = tile[fill]
    required = geometry_mask([expanded], out_shape=mosaic.shape,
                             transform=transform, invert=True)
    missing = int(np.count_nonzero(required & ~np.isfinite(mosaic)))
    if missing:
        raise ValueError(f"DEM has {missing} uncovered pixels in/near study area; add tiles")
    return DEMGrid(mosaic, transform, CRS.from_user_input(metric_crs))


@dataclass
class Building:
    geometry: object
    top_altitude_m: float


def load_buildings(paths, study_area, metric_crs, dem: DEMGrid,
                   height_field: str, height_mode: str, clearance_m: float):
    if height_mode not in {"agl", "amsl"}:
        raise ValueError("height_mode must be agl or amsl")
    expanded = study_area.buffer(clearance_m)
    buildings = []
    stats = {"rows_read": 0, "invalid_height": 0, "missing_dem": 0,
             "outside_site": 0, "accepted": 0,
             "single_cell_ground": 0, "multi_cell_median_ground": 0}
    for path in paths:
        info = pyogrio.read_info(path)
        source_crs = info["crs"]
        fields = list(info["fields"])
        if source_crs is None:
            raise ValueError(f"Building data lacks CRS: {path}")
        if height_field not in fields:
            raise ValueError(f"Height field '{height_field}' absent in {path}; fields: {fields}")
        to_source = Transformer.from_crs(metric_crs, source_crs, always_xy=True)
        bbox = to_source.transform_bounds(*expanded.bounds, densify_pts=21)
        frame = pyogrio.read_dataframe(path, bbox=bbox, columns=[height_field])
        stats["rows_read"] += len(frame)
        if frame.empty:
            continue
        frame = frame.to_crs(metric_crs)
        for geometry, raw_height in zip(frame.geometry, frame[height_field]):
            if geometry is None or geometry.is_empty:
                stats["outside_site"] += 1
                continue
            fixed = geometry if geometry.is_valid else geometry.buffer(0)
            if fixed.is_empty or not fixed.intersects(expanded):
                stats["outside_site"] += 1
                continue
            try:
                height = float(raw_height)
            except (TypeError, ValueError):
                height = float("nan")
            if not isfinite(height) or height <= 0:
                stats["invalid_height"] += 1
                continue
            if height_mode == "agl":
                ground, cell_count = dem.sample_building_ground(
                    fixed.intersection(expanded))
                if not isfinite(ground):
                    stats["missing_dem"] += 1
                    continue
                if cell_count == 1:
                    stats["single_cell_ground"] += 1
                else:
                    stats["multi_cell_median_ground"] += 1
                top = ground + height
            else:
                top = height
            buildings.append(Building(fixed, top))
            stats["accepted"] += 1
    return buildings, stats
