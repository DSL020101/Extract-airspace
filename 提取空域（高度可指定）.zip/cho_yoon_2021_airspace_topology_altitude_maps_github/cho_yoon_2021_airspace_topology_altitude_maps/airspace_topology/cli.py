"""Command-line pipeline from footprints and DEM to segment/Reeb graphs."""

from __future__ import annotations

import argparse
from pathlib import Path

import pyogrio
import rasterio

from .data import (RASTER_SUFFIXES, VECTOR_SUFFIXES, collect_paths,
                   load_buildings, load_dem, make_study_area)
from .filtration import extract_layer
from .geometry import buffer_and_subtract, triangulate_free_space
from .output import write_layer, write_summary
from .vertical import vertical_edges


def parse_levels(text):
    if ":" in text:
        start, stop, step = (float(value) for value in text.split(":"))
        if step <= 0 or stop < start:
            raise ValueError("levels must be start:stop:positive_step")
        count = round((stop - start) / step)
        levels = [start + i * step for i in range(count + 1)]
        if levels[-1] > stop + 1e-8:
            levels.pop()
    else:
        levels = [float(value) for value in text.split(",")]
    if not levels or any(b <= a for a, b in zip(levels, levels[1:])):
        raise ValueError("altitudes must be nonempty and strictly increasing")
    return levels


def inspect(path):
    paths = collect_paths([path], VECTOR_SUFFIXES | RASTER_SUFFIXES)
    if len(paths) > 10:
        print(f"Found {len(paths)} data files; showing first 10. Pass one file to inspect it.")
    for file in paths[:10]:
        print(file)
        if file.suffix.lower() in VECTOR_SUFFIXES:
            info = pyogrio.read_info(file)
            print(f"  CRS: {info['crs']}")
            print(f"  features: {info['features']}")
            print(f"  fields: {list(info['fields'])}")
        else:
            with rasterio.open(file) as dataset:
                print(f"  CRS: {dataset.crs}")
                print(f"  extent: {dataset.bounds}")
                print(f"  resolution: {dataset.res}")


def run(args):
    levels = parse_levels(args.levels)
    study, crs = make_study_area(
        args.center_lon, args.center_lat, args.radius_m,
        args.boundary, args.metric_crs)
    building_paths = collect_paths(args.buildings, VECTOR_SUFFIXES)
    dem_paths = collect_paths(args.dem, RASTER_SUFFIXES)
    print(f"Study CRS: {crs}; area: {study.area:.0f} m²")
    dem = load_dem(dem_paths, study, crs, args.dem_resolution, args.clearance)
    buildings, building_stats = load_buildings(
        building_paths, study, crs, dem, args.height_field,
        args.height_mode, args.clearance)
    print(f"Buildings: {building_stats}")
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    layers = []
    for altitude in levels:
        expanded = study.buffer(args.clearance)
        terrain = dem.terrain_obstacles(altitude, expanded)
        active_buildings = [b.geometry for b in buildings if b.top_altitude_m > altitude]
        free = buffer_and_subtract(study, [*terrain, *active_buildings],
                                   args.clearance)
        mesh = triangulate_free_space(free, args.contour_spacing)
        layer = extract_layer(mesh, altitude, args.r, args.alpha,
                              args.circle_tolerance, args.layer_thickness)
        layer.metrics.update({
            "segment_area_percent_of_study": 100 * layer.metrics["segment_area_m2"] / study.area,
            "passage_area_percent_of_study": 100 * layer.metrics["passage_area_m2"] / study.area,
            "available_area_percent_of_study": 100 * (
                layer.metrics["segment_area_m2"] + layer.metrics["passage_area_m2"]
            ) / study.area,
        })
        layers.append(layer)
        path = write_layer(out_dir, layer, crs, study, free)
        print(f"h={altitude:g} m: {len(mesh.faces)} triangles, "
              f"{len(layer.segments)} segments, {len(layer.passages)} passages -> {path}")
    vertical = vertical_edges(layers, args.vertical_min_overlap_area)
    metadata = {
        "method": "Independent triangle-filtration reproduction of Cho & Yoon (2021)",
        "paper_doi": "10.1016/j.trc.2021.103116",
        "metric_crs": crs.to_string(),
        "altitudes_m": levels,
        "layer_thickness_m": args.layer_thickness,
        "clearance_m": args.clearance,
        "containment_radius_m": args.r,
        "width_parameter_m": args.alpha,
        "contour_spacing_m": args.contour_spacing,
        "dem_resolution_m": args.dem_resolution,
        "height_field": args.height_field,
        "height_mode": args.height_mode,
        "ground_sampling": ("median of valid DEM cells touched by each building; "
                            "single cell uses that cell" if args.height_mode == "agl"
                            else "not used for absolute roof altitude"),
        "building_stats": building_stats,
        "buildings": [str(p) for p in building_paths],
        "dem": [str(p) for p in dem_paths],
        "vertical_min_overlap_area_m2": args.vertical_min_overlap_area,
        "notes": "Input elevations and analysis altitudes must use compatible vertical datums.",
    }
    write_summary(out_dir, layers, vertical, metadata)
    print(f"Vertical edges: {len(vertical)}; outputs: {out_dir}")


def build_parser():
    parser = argparse.ArgumentParser(prog="airspace-topology")
    sub = parser.add_subparsers(dest="command", required=True)
    examine = sub.add_parser("inspect", help="Show CRS and fields of source data")
    examine.add_argument("path")
    process = sub.add_parser("run", help="Extract airspace and graphs")
    process.add_argument("--buildings", nargs="+", required=True,
                         help="Building vector file(s) or extracted directory")
    process.add_argument("--dem", nargs="+", required=True,
                         help="DEM GeoTIFF tile(s) or directory")
    process.add_argument("--height-field", required=True,
                         help="Building height attribute; use inspect first")
    process.add_argument("--height-mode", choices=["agl", "amsl"], default="agl",
                         help="AGL: height above sampled terrain; AMSL: absolute roof altitude")
    process.add_argument("--boundary", help="Study polygon vector file")
    process.add_argument("--center-lon", type=float)
    process.add_argument("--center-lat", type=float)
    process.add_argument("--radius-m", type=float)
    process.add_argument("--metric-crs", help="Projected metre CRS; default local UTM")
    process.add_argument("--levels", default="10:150:10",
                         help="Absolute altitude metres: 10:150:10 or 50,60,70")
    process.add_argument("--layer-thickness", type=float, default=10.0,
                         help="Fixed vertical layer thickness epsilon in metres")
    process.add_argument("--clearance", type=float, default=30.0)
    process.add_argument("--r", type=float, default=10.0,
                         help="Aircraft containment radius in metres")
    process.add_argument("--alpha", type=float, default=60.0,
                         help="Segment width parameter (disc radius) in metres")
    process.add_argument("--contour-spacing", type=float, default=1.0,
                         help="Maximum boundary point spacing in metres")
    process.add_argument("--dem-resolution", type=float, default=30.0,
                         help="Resampling grid size in metres")
    process.add_argument("--circle-tolerance", type=float, default=0.5)
    process.add_argument("--vertical-min-overlap-area", type=float, default=0.0)
    process.add_argument("--output", required=True)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "inspect":
        inspect(args.path)
    else:
        if args.clearance < 0 or args.r <= 0 or args.alpha < args.r or args.layer_thickness <= 0:
            parser.error("Need clearance >= 0, alpha >= r > 0, layer thickness > 0")
        run(args)


if __name__ == "__main__":
    main()
