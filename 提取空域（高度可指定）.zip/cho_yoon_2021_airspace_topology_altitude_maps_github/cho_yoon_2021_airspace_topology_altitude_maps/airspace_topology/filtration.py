"""Sections 4.1–4.2.2: circumradius filtration and segment graph."""

from __future__ import annotations

from dataclasses import dataclass, field
from math import floor

from shapely import maximum_inscribed_circle
from shapely.geometry import LineString
from shapely.ops import unary_union

from .geometry import TriangleMesh


@dataclass
class Region:
    id: str
    triangle_ids: tuple[int, ...]
    geometry: object
    area: float
    kind: str  # segment or passage
    passage_type: str | None = None
    maximum_inscribed_radius: float | None = None
    vehicle_capacity: int | None = None
    degree: int | None = None


@dataclass
class Gate:
    id: str
    segment_id: str
    passage_id: str
    segment_triangle_id: int
    passage_triangle_id: int
    shared_edge: LineString


@dataclass
class LayerResult:
    altitude: float
    containment_radius: float
    width_parameter: float
    mesh: TriangleMesh
    thickness: float = 10.0
    segments: list[Region] = field(default_factory=list)
    passages: list[Region] = field(default_factory=list)
    gates: list[Gate] = field(default_factory=list)
    segment_passage_edges: list[tuple[str, str]] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)


def _components(mesh: TriangleMesh, selected: set[int]):
    """Connected components by shared triangle edge at one filtration level.

    This is the final-state equivalent of Algorithm 1's descending disjoint-set
    sweep. Keeping the two threshold classes separate prevents a passage from
    merging two distinct segment roots.
    """
    unseen = set(selected)
    result = []
    while unseen:
        seed = min(unseen)
        unseen.remove(seed)
        stack = [seed]
        group = [seed]
        while stack:
            current = stack.pop()
            for other in mesh.neighbors[current] & unseen:
                unseen.remove(other)
                stack.append(other)
                group.append(other)
        result.append(tuple(sorted(group)))
    return sorted(result, key=lambda group: group[0])


def _region(mesh, triangle_ids, kind, identifier):
    geometry = unary_union([mesh.polygons[i] for i in triangle_ids])
    return Region(identifier, triangle_ids, geometry, float(geometry.area), kind)


def _available_components(mesh, selected):
    return len(_components(mesh, selected))


def extract_layer(mesh: TriangleMesh, altitude: float, containment_radius: float,
                  width_parameter: float, circle_tolerance: float = 0.5,
                  layer_thickness: float = 10.0) -> LayerResult:
    """Extract the paper's triangle-based segment and passage polytopes.

    Segment: circumradius rho >= alpha.
    Passage: r <= rho < alpha.
    Closed by r: rho < r.
    Gate: a segment triangle sharing an edge with a passage triangle.

    The union of qualifying *whole triangles* is deliberately retained. It is
    the paper's approximation, not an exact configuration-space erosion.
    """
    r = float(containment_radius)
    alpha = float(width_parameter)
    if r <= 0 or alpha < r or circle_tolerance <= 0 or layer_thickness <= 0:
        raise ValueError("Require r > 0, alpha >= r, circle_tolerance > 0, layer_thickness > 0")
    segments_set = {i for i, rho in enumerate(mesh.radii) if rho >= alpha}
    passages_set = {i for i, rho in enumerate(mesh.radii) if r <= rho < alpha}
    available_set = segments_set | passages_set
    result = LayerResult(float(altitude), r, alpha, mesh, float(layer_thickness))
    result.segments = [
        _region(mesh, group, "segment", f"S{index + 1}")
        for index, group in enumerate(_components(mesh, segments_set))
    ]
    result.passages = [
        _region(mesh, group, "passage", f"P{index + 1}")
        for index, group in enumerate(_components(mesh, passages_set))
    ]
    segment_of = {i: region.id for region in result.segments for i in region.triangle_ids}
    passage_of = {i: region.id for region in result.passages for i in region.triangle_ids}
    for seg_tri in sorted(segments_set):
        for pass_tri in sorted(mesh.neighbors[seg_tri] & passages_set):
            common = sorted(set(mesh.faces[seg_tri]) & set(mesh.faces[pass_tri]))
            if len(common) != 2:
                raise AssertionError("Adjacent triangles must share exactly two vertices")
            edge = LineString([tuple(mesh.vertices[common[0]]),
                               tuple(mesh.vertices[common[1]])])
            result.gates.append(Gate(
                f"G{len(result.gates) + 1}", segment_of[seg_tri],
                passage_of[pass_tri], seg_tri, pass_tri, edge))
    result.segment_passage_edges = sorted({(g.segment_id, g.passage_id)
                                           for g in result.gates})
    gates_by_passage = {}
    for gate in result.gates:
        gates_by_passage.setdefault(gate.passage_id, []).append(gate)
    for passage in result.passages:
        gates = gates_by_passage.get(passage.id, [])
        attached_segments = {gate.segment_id for gate in gates}
        if len(attached_segments) >= 2:
            passage.passage_type = "external"
        elif len({gate.segment_triangle_id for gate in gates}) >= 2:
            passage.passage_type = "internal"
        elif gates:
            passage.passage_type = "dead_end"
        else:
            passage.passage_type = "unattached"  # uncovered by paper's 3-way list
        if not passage.geometry.is_empty:
            circle = maximum_inscribed_circle(passage.geometry,
                                               tolerance=circle_tolerance)
            passage.maximum_inscribed_radius = float(circle.length)
            passage.vehicle_capacity = floor(circle.length / r + 1e-9)
    neighbor_segments = {region.id: set() for region in result.segments}
    for passage in result.passages:
        attached = {gate.segment_id for gate in gates_by_passage.get(passage.id, [])}
        for segment_id in attached:
            neighbor_segments[segment_id].update(attached - {segment_id})
    for segment in result.segments:
        segment.degree = len(neighbor_segments[segment.id])
    segment_area = sum(s.area for s in result.segments)
    passage_area = sum(p.area for p in result.passages)
    closed_area = sum(mesh.polygons[i].area for i, rho in enumerate(mesh.radii) if rho < r)
    result.metrics = {
        "altitude_m": float(altitude),
        "layer_thickness_m": float(layer_thickness),
        "free_after_clearance_area_m2": mesh.free_area,
        "segment_area_m2": segment_area,
        "passage_area_m2": passage_area,
        "segment_volume_m3": segment_area * layer_thickness,
        "passage_volume_m3": passage_area * layer_thickness,
        "closed_by_r_area_m2": closed_area,
        "triangulation_area_error_m2": (segment_area + passage_area + closed_area
                                         - mesh.free_area),
        "segment_count": len(result.segments),
        "passage_count": len(result.passages),
        "external_passage_count": sum(p.passage_type == "external" for p in result.passages),
        "internal_passage_count": sum(p.passage_type == "internal" for p in result.passages),
        "dead_end_count": sum(p.passage_type == "dead_end" for p in result.passages),
        "available_component_count": _available_components(mesh, available_set),
        "mean_segment_degree": (sum(s.degree for s in result.segments)
                                / len(result.segments) if result.segments else 0.0),
        "passage_to_segment_area_ratio": (passage_area / segment_area
                                          if segment_area else None),
    }
    return result
