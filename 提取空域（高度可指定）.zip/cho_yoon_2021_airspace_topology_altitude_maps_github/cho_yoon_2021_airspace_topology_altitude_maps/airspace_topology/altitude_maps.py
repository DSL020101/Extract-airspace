"""Configurable absolute-altitude maps using the existing city raster rule.

This computes a new horizontal slice from terrain and roof elevations. It does
not interpolate existing 10 m slices or extract segment/passage/gate topology.
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime
from decimal import Decimal, InvalidOperation
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

import numpy as np
import pyogrio
import rasterio
from rasterio.enums import Resampling
from rasterio.features import geometry_mask
from scipy import ndimage


def decimal_height(value):
    try:
        height = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise argparse.ArgumentTypeError("Altitude must be a finite number") from None
    if not height.is_finite():
        raise argparse.ArgumentTypeError("Altitude must be a finite number")
    return height


def select_altitudes(altitude, start, stop, step, default):
    batch = start is not None or stop is not None
    if batch:
        if altitude is not None or start is None or stop is None:
            raise ValueError("Use --altitude OR both --start and --stop")
        first, last, increment = map(decimal_height, (start, stop, step))
        if increment <= 0 or last < first:
            raise ValueError("Require --step > 0 and --stop >= --start")
        count = int((last - first) // increment) + 1
        return [first + index * increment for index in range(count)]
    return [decimal_height(default if altitude is None else altitude)]


def altitude_tag(value):
    text = format(decimal_height(value).normalize(), "f")
    negative = text.startswith("-")
    integer, _, fraction = text.lstrip("-").partition(".")
    return ("minus_" if negative else "") + integer.zfill(3) + ("p" + fraction if fraction else "") + "m"


def screen_at_altitude(dem, valid_dem, roof, valid_roof, city, altitude):
    """Return a fresh mask; roof==h is inactive and terrain==h is blocked.

    Terrain clearance retains the original one-cell cardinal dilation. The
    roof raster already includes the original 30 m building polygon buffer.
    """
    level = float(decimal_height(altitude))
    if not np.isfinite(level):
        raise ValueError("Altitude is outside the supported numeric range")
    terrain = valid_dem & (dem >= level)
    terrain_buffered = ndimage.binary_dilation(
        terrain, structure=ndimage.generate_binary_structure(2, 1)
    )
    building = valid_roof & (roof > level)
    return city & valid_dem & ~terrain_buffered & ~building


def load_inputs(data_dir):
    dem_path = data_dir / "hangzhou_dem_utm51_30m.tif"
    roof_path = data_dir / "roof_clearance_max_30m.tif"
    boundary_path = data_dir / "hangzhou_boundary_reference.geojson"
    for path in (dem_path, roof_path, boundary_path):
        if not path.is_file():
            raise FileNotFoundError(f"Required input is missing: {path}. See data/README.md.")
    with rasterio.open(dem_path) as source:
        dem = source.read(1)
        valid_dem = np.isfinite(dem) & (source.read_masks(1) != 0)
        profile = source.profile
        if source.crs is None or not source.crs.is_projected:
            raise ValueError("DEM must use a projected coordinate system in metres")
        if not np.allclose(source.res, (30, 30)):
            raise ValueError("This version retains the original 30 m grid/clearance rule")
    with rasterio.open(roof_path) as source:
        if (source.shape != dem.shape or source.crs != profile["crs"]
                or source.transform != profile["transform"]):
            raise ValueError("Roof and DEM grids must have identical CRS, shape and transform")
        roof = source.read(1)
        valid_roof = np.isfinite(roof) & (source.read_masks(1) != 0)
    boundary = pyogrio.read_dataframe(boundary_path)
    if boundary.crs is None or boundary.empty:
        raise ValueError("Boundary must be nonempty and declare its CRS")
    boundary = boundary.to_crs(profile["crs"])
    city = geometry_mask(boundary.geometry, out_shape=dem.shape,
                         transform=profile["transform"], invert=True)
    if not city.any() or np.any(city & ~valid_dem):
        raise ValueError("Study boundary is empty or DEM contains NoData inside it")
    paths = {"dem": str(dem_path), "buffered_roof": str(roof_path),
             "boundary": str(boundary_path)}
    return dem, valid_dem, roof, valid_roof, city, profile, paths


def write_raster(path, free, city, profile, altitude):
    settings = profile.copy()
    settings.pop("predictor", None)
    settings.update(driver="GTiff", dtype="uint8", count=1, nodata=255,
                    compress="DEFLATE", tiled=True, blockxsize=256, blockysize=256)
    values = np.where(city, free, 255).astype("uint8")
    with rasterio.open(path, "w", **settings) as target:
        target.write(values, 1)
        target.update_tags(absolute_altitude_m=str(altitude),
                           method="candidate free-space screening, 30 m grid",
                           values="0=blocked, 1=candidate free, 255=outside Hangzhou")


def render_map(raster_path, png_path, altitude, settings):
    if importlib.util.find_spec("matplotlib") is not None:
        python = Path(sys.executable)
    else:
        configured = os.environ.get("AIRSPACE_PLOT_PYTHON") or settings.PLOT_PYTHON
        local_path = Path(settings.PROJECT_DIR) / "plot_python_path.local"
        if not configured and local_path.is_file():
            configured = local_path.read_text(encoding="utf-8-sig").strip()
        if not configured:
            raise RuntimeError("Install matplotlib in this Python environment, or set PLOT_PYTHON in altitude_config.py")
        python = Path(configured).expanduser()
    if not python.is_file():
        raise FileNotFoundError(f"Plotting Python was not found: {python}")
    renderer = Path(__file__).resolve().parents[1] / "render_altitude_map.py"
    with rasterio.open(raster_path) as source:
        scale = min(1.0, settings.PREVIEW_MAX_WIDTH / source.width)
        shape = (max(1, round(source.height * scale)), max(1, round(source.width * scale)))
        preview = source.read(1, out_shape=shape, resampling=Resampling.nearest)
    # A temporary preview bridges the existing GIS and plotting environments.
    # Areas and GeoTIFFs are calculated from the full-resolution grid.
    with tempfile.TemporaryDirectory(prefix="altitude_map_") as cache:
        array_path = Path(cache) / "preview.npz"
        np.savez_compressed(array_path, values=preview)
        command = [str(python), str(renderer), str(array_path), str(png_path),
                   "--altitude", str(altitude), "--dpi", str(settings.FIGURE_DPI)]
        if settings.SHOW_LEGEND:
            command.append("--legend")
        subprocess.run(command, check=True)


def main(argv=None):
    import altitude_config as settings

    parser = argparse.ArgumentParser(description="Draw Hangzhou candidate free space at an absolute altitude")
    parser.add_argument("--altitude", type=decimal_height, help="Single absolute altitude in metres")
    parser.add_argument("--start", type=decimal_height, help="First batch altitude (inclusive)")
    parser.add_argument("--stop", type=decimal_height, help="Last batch altitude (inclusive when on the step grid)")
    parser.add_argument("--step", type=decimal_height, default=Decimal(1), help="Batch interval in metres; default 1")
    args = parser.parse_args(argv)
    try:
        heights = select_altitudes(args.altitude, args.start, args.stop, args.step, settings.ALTITUDE_M)
    except (ValueError, argparse.ArgumentTypeError) as error:
        parser.error(str(error))
    output = Path(settings.OUTPUT_DIR).resolve()
    output.mkdir(parents=True, exist_ok=True)
    print(f"Loading Hangzhou DEM and roof data; requested maps: {len(heights)}", flush=True)
    dem, valid_dem, roof, valid_roof, city, profile, paths = load_inputs(Path(settings.DATA_DIR))
    city_cells = int(city.sum())
    transform = profile["transform"]
    pixel_area = abs(transform.a * transform.e - transform.b * transform.d)
    rows = []
    for altitude in heights:
        tag = altitude_tag(altitude)
        print(f"Computing absolute altitude {altitude} m ...", flush=True)
        free = screen_at_altitude(dem, valid_dem, roof, valid_roof, city, altitude)
        free_cells = int(free.sum())
        raster_path = output / f"free_{tag}.tif"
        png_path = output / f"free_{tag}.png"
        write_raster(raster_path, free, city, profile, altitude)
        render_map(raster_path, png_path, altitude, settings)
        row = {"absolute_altitude_m": float(altitude), "free_cells": free_cells,
               "approx_free_area_km2": free_cells * pixel_area / 1e6,
               "free_percent_of_rasterized_city": 100 * free_cells / city_cells}
        metadata = {
            **row, "created_local": datetime.now().isoformat(timespec="seconds"),
            "method": "30 m candidate free-space screening at a requested horizontal plane",
            "not_paper_segment_passage_gate": True,
            "altitude_reference": "same vertical datum as the prepared DEM; not height above local ground",
            "fresh_computation_from_dem_and_roofs": True, "interpolation_between_altitude_layers": False,
            "horizontal_resolution_m": 30, "crs": profile["crs"].to_string(),
            "terrain_blocked_when": "DEM >= altitude, followed by one-cell cardinal dilation",
            "building_blocked_when": "30 m buffered roof raster > altitude",
            "roof_preparation": "median ground DEM of touched cells + CMAB Height; polygon buffered by 30 m",
            "input_files": paths, "raster": str(raster_path), "figure": str(png_path),
            "figure_preview_resampling": "nearest neighbor; statistics use full resolution",
            "value_labels": {"0": "blocked", "1": "candidate free", "255": "outside Hangzhou"},
        }
        (output / f"free_{tag}.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        rows.append(row)
        print(f"Saved free_{tag}.png and .tif; candidate free area {row['approx_free_area_km2']:.4f} km2", flush=True)
    name = ("summary_" + altitude_tag(heights[0]) +
            ("_to_" + altitude_tag(heights[-1]) if len(heights) > 1 else "") + ".csv")
    with (output / name).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Finished. Output folder: {output}", flush=True)


if __name__ == "__main__":
    main()
