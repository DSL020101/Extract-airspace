"""Section 4.2.1: buffered obstacles and constrained Delaunay triangles.

All coordinates and distances here MUST be in the same planar metre CRS.
The underlying Triangle library performs a PSLG constrained Delaunay
triangulation (its ``p`` switch). No quality/area refinement switches are used,
because added interior points change the paper's circumradius filtration.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil, hypot, inf

import numpy as np
import triangle as tr
from shapely.geometry import Polygon
from shapely.ops import unary_union


@dataclass
class TriangleMesh:
    vertices: np.ndarray  # (N, 2), metres
    faces: np.ndarray  # (M, 3), indices into vertices
    radii: np.ndarray  # (M,), circumcircle radii in metres
    neighbors: list[set[int]]  # adjacency by shared whole edge
    polygons: list[Polygon]  # one polygon per triangle
    free_area: float  # buffered-obstacle complement area


def _polygons(geometry):
    if geometry.is_empty:
        return
    if geometry.geom_type == "Polygon":
        yield geometry
    elif geometry.geom_type == "MultiPolygon":
        yield from geometry.geoms
    elif geometry.geom_type == "GeometryCollection":
        for item in geometry.geoms:
            yield from _polygons(item)


def buffer_and_subtract(study_area, obstacle_geometries, clearance: float):
    """Construct A_h(delta) = study area minus buffered 2-D obstacles.

    Obstacles may lie outside the study boundary; their buffers still affect
    the part inside it. ``clearance`` is applied to every supplied obstacle,
    following the formal O_h(delta) equation in the paper.
    """
    if clearance < 0:
        raise ValueError("clearance must be nonnegative")
    if study_area.is_empty or not study_area.is_valid:
        raise ValueError("study_area must be a nonempty valid polygon")
    expanded = study_area.buffer(clearance)
    clipped = []
    for geom in obstacle_geometries:
        if geom is None or geom.is_empty or not geom.intersects(expanded):
            continue
        fixed = geom if geom.is_valid else geom.buffer(0)
        if not fixed.is_empty:
            clipped.append(fixed.intersection(expanded))
    if not clipped:
        return study_area
    obstacles = unary_union(clipped)
    buffered = obstacles.buffer(clearance) if clearance else obstacles
    result = study_area.difference(buffered)
    return result if result.is_valid else result.buffer(0)


def _sample_ring(ring, max_spacing: float):
    base = list(ring.coords)
    if len(base) < 4:
        raise ValueError("invalid polygon ring")
    result = []
    for a, b in zip(base[:-1], base[1:]):
        distance = hypot(b[0] - a[0], b[1] - a[1])
        n = max(1, ceil(distance / max_spacing))
        for k in range(n):
            result.append((a[0] + (b[0] - a[0]) * k / n,
                           a[1] + (b[1] - a[1]) * k / n))
    return result


def _pslg(polygon: Polygon, max_spacing: float):
    vertices = []
    segments = []
    holes = []
    for ring in [polygon.exterior, *polygon.interiors]:
        sampled = _sample_ring(ring, max_spacing)
        start = len(vertices)
        vertices.extend(sampled)
        count = len(sampled)
        segments.extend((start + i, start + (i + 1) % count)
                        for i in range(count))
    for ring in polygon.interiors:
        marker = Polygon(ring).representative_point()
        holes.append((marker.x, marker.y))
    result = {
        "vertices": np.asarray(vertices, dtype=np.float64),
        "segments": np.asarray(segments, dtype=np.int32),
    }
    if holes:
        result["holes"] = np.asarray(holes, dtype=np.float64)
    return result


def _circumradius(a, b, c):
    ab = hypot(*(a - b))
    bc = hypot(*(b - c))
    ca = hypot(*(c - a))
    twice_area = abs((b[0] - a[0]) * (c[1] - a[1])
                     - (b[1] - a[1]) * (c[0] - a[0]))
    if twice_area <= 1e-12:
        return inf
    return ab * bc * ca / (2.0 * twice_area)


def triangulate_free_space(free_space, max_spacing: float = 1.0) -> TriangleMesh:
    """Sample each contour at <= max_spacing and triangulate each component.

    Each input polygon is triangulated separately; this also prevents false
    adjacency between disconnected regions that merely touch at a point.
    """
    if max_spacing <= 0:
        raise ValueError("max_spacing must be positive")
    vertices_parts = []
    faces_parts = []
    for polygon in _polygons(free_space):
        if polygon.area <= 1e-10:
            continue
        pslg = _pslg(polygon, max_spacing)
        answer = tr.triangulate(pslg, "pQ")
        if "triangles" not in answer:
            raise RuntimeError("Constrained Delaunay triangulation returned no triangles")
        offset = sum(len(part) for part in vertices_parts)
        vertices_parts.append(np.asarray(answer["vertices"], dtype=np.float64))
        faces_parts.append(np.asarray(answer["triangles"], dtype=np.int32) + offset)
    if not faces_parts:
        return TriangleMesh(np.empty((0, 2)), np.empty((0, 3), dtype=np.int32),
                            np.empty(0), [], [], float(free_space.area))
    vertices = np.concatenate(vertices_parts)
    faces = np.concatenate(faces_parts)
    radii = np.array([_circumradius(*vertices[face]) for face in faces])
    if not np.isfinite(radii).all():
        raise RuntimeError("Triangulation contains a degenerate triangle")
    polygons = [Polygon(vertices[face]) for face in faces]
    neighbors = [set() for _ in range(len(faces))]
    owners = {}
    for index, face in enumerate(faces):
        for u, v in ((face[0], face[1]), (face[1], face[2]), (face[2], face[0])):
            edge = tuple(sorted((int(u), int(v))))
            other = owners.get(edge)
            if other is None:
                owners[edge] = index
            else:
                neighbors[index].add(other)
                neighbors[other].add(index)
    return TriangleMesh(vertices, faces, radii, neighbors, polygons,
                        float(free_space.area))
