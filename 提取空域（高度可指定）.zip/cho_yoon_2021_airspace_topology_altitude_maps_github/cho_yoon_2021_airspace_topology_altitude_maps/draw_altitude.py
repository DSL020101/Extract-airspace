"""Entry point: use altitude_config.py or --altitude / --start / --stop."""

from airspace_topology.altitude_maps import main


if __name__ == "__main__":
    main()
